import { Component } from '@angular/core';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  // constructor(private permissionsService: NgxPermissionsService) {
  //   // ตั้งค่าสิทธิ์สำหรับ LoginComponent สำหรับผู้ใช้ทั่วไป
  //   const userPermissions = ['user'];
  //   this.permissionsService.loadPermissions(userPermissions);
  // }
}
