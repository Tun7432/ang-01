import { Component } from '@angular/core';

@Component({
  selector: 'app-manage-lottery',
  templateUrl: './manage-lottery.component.html',
  styleUrls: ['./manage-lottery.component.css']
})
export class ManageLotteryComponent {

}
//จัดการข้อมูลสลาก