import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LotteryServiceService {

  constructor() { }
}
//ใช้สำหรับการค้นหาและจัดการข้อมูลสลาก