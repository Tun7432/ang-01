import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

// โมดูลสำหรับส่วนของผู้ดูแลระบบ (Admin) ที่นำเข้า Component และกำหนดเส้นทางที่เฉพาะกับ Admin
@NgModule({
  declarations: [],
  imports: [CommonModule],
})
export class AdminModuleModule {}
