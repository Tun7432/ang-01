import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ReportServiceService {

  constructor() { }
}
//ใช้สำหรับสร้างรายงานเกี่ยวกับการซื้อสลาก
