// lottery-search.component.ts
import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { Lottery, Convert as lotteryCvt } from 'src/app/model/Lottery.model';
import { LotteryService } from 'src/app/services/lottery.service';
@Component({
  selector: 'app-lottery-search',
  templateUrl: './lottery-search.component.html',
  styleUrls: ['./lottery-search.component.css']
})
export class LotterySearchComponent {
[x: string]: any;
  lotteryResults = Array<Lottery>();
  isMultiple = false;
  lotteriesByNumber = new Array<any>();

  constructor(private lotteryService: LotteryService, private http: HttpClient) {
    // เรียก API และแปลงข้อมูลให้กับ lottery
    http.get(lotteryService.apiEndpoint+"/lottery").subscribe((data: any) => {
      console.log(data); // เพิ่มบรรทัดนี้
      this.lotteryResults = lotteryCvt.toLottery(JSON.stringify(data));
      console.log(data[0]);
      console.log(this.lotteryResults);
      this.isMultiple = this.lotteryService.isMultiple;
      this.lotteriesByNumber = this.lotteryService.lotteriesByNumber;
    });
  }
  
  getInputValues(): string {
    let concatenatedValue = '';
    for (let i = 1; i <= 6; i++) {
      const inputElement = document.getElementsByName('input' + (i-1))[0] as HTMLInputElement;
      if (inputElement) {
        concatenatedValue += inputElement.value;
      }
    }
    return concatenatedValue;
  }
  
  search(input: string) {
    this.isMultiple = true;
    this.lotteriesByNumber = [];
    const inputArray = input.split(','); // แปลงข้อมูล input เป็นอาร์เรย์ของ string
  
    // แปลงอาร์เรย์ของ string เป็นอาร์เรย์ของตัวเลข
    const ticketNumbers = inputArray.map(inputItem => Number(inputItem.trim())); // เปลี่ยนชื่อตัวแปร input เป็น inputItem
  
    for (let index = 0; index < this.lotteryResults.length; index++) {
      const lottery = this.lotteryResults[index];
      
      // แปลง lottery.ticket_number เป็นสตริงก่อนใช้ split()
      const lotteryNumbers = lottery.ticket_number.toString().split(',').map(Number);
  
      // ตรวจสอบว่าตัวเลขทั้งหมดใน ticketNumbers มีอยู่ใน lotteryNumbers หรือไม่
      const hasAllNumbers = ticketNumbers.every(number => lotteryNumbers.includes(number));
  
      // แปลงตัวเลขใน ticketNumbers เป็นสตริงก่อนใช้ indexOf และ lastIndexOf
      const ticketNumberStrings = ticketNumbers.map(number => number.toString());
      
      // ตรวจสอบว่ามีตัวเลขที่ขึ้นต้นด้วยหรือลงท้ายด้วยค่าใน ticketNumbers หรือไม่
      const startsWithNumber = ticketNumberStrings.some(inputNumber => 
        lotteryNumbers.some(lotteryNumber => 
          lotteryNumber.toString().startsWith(inputNumber)
        )
      );
      
      const endsWithNumber = ticketNumberStrings.some(inputNumber => 
        lotteryNumbers.some(lotteryNumber => 
          lotteryNumber.toString().endsWith(inputNumber)
        )
      );
  
      if (hasAllNumbers || startsWithNumber || endsWithNumber) {
        this.lotteriesByNumber.push(lottery);
      }
      
    }
    console.log(this.lotteriesByNumber);
    console.log(ticketNumbers);
  }
  
  
}


