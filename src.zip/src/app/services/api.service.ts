import { Injectable } from '@angular/core';
import { ApiModule } from '../modules/api/api.module';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  constructor() { }
}
