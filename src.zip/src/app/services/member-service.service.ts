import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MemberServiceService {

  constructor() { }
}
//ใช้สำหรับการจัดการข้อมูลสมาชิกและประวัติการซื้อสลาก