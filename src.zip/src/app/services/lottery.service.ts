import { Injectable } from '@angular/core';
import { MemberDataService } from './member-data.service';
@Injectable({
  providedIn: 'root'
})
export class LotteryService {
  apiEndpoint = 'http://localhost/Webservice';
  countries: any;
  isLoggedIn: boolean = false;
  constructor(private memberDataService :MemberDataService) { }
  setMemberName(name: string) {
    this.memberDataService.setMemberName(name);
  }
}
