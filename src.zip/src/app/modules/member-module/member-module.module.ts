import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

//โมดูลสำหรับส่วนของสมาชิก (Member) ที่นำเข้า Component และกำหนดเส้นทางที่เฉพาะกับ Membe

@NgModule({
  declarations: [],
  imports: [
    CommonModule
  ]
})
export class MemberModuleModule { }
