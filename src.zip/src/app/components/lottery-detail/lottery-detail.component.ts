import { Component } from '@angular/core';

@Component({
  selector: 'app-lottery-detail',
  templateUrl: './lottery-detail.component.html',
  styleUrls: ['./lottery-detail.component.css']
})
export class LotteryDetailComponent {

}
// แสดงรายละเอียดของสลากหลังจากค้นหา