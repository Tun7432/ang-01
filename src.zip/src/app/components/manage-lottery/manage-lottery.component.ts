import { Component } from '@angular/core';

@Component({
  selector: 'app-manage-lottery',
  templateUrl: './manage-lottery.component.html',
  styleUrls: ['./manage-lottery.component.css']
})
export class ManageLotteryComponent {
  gridColumns = 3;
  lotteryNumbers: string[] = ['', '', '', '', '', ''];

  onNumberInputChange() {
    // ทำอะไรสักอย่างเมื่อมีการเปลี่ยนแปลงในช่องป้อนหมายเลข
  }

  searchLottery() {
    const numbers = this.lotteryNumbers.join('');
    // ทำอะไรสักอย่างเมื่อปุ่มค้นหาถูกคลิก
  }

  lotteryResults = [
    {
      title: 'Lottery Result 1',
      lotteryNumber: '12345',
      drawNo: 'Draw #1',
    },
    {
      title: 'Lottery Result 2',
      lotteryNumber: '54321',
      drawNo: 'Draw #2',
    },
    {
      title: 'Lottery Result 1',
      lotteryNumber: '12345',
      drawNo: 'Draw #1',
    },
    {
      title: 'Lottery Result 2',
      lotteryNumber: '54321',
      drawNo: 'Draw #2',
    },
    {
      title: 'Lottery Result 1',
      lotteryNumber: '12345',
      drawNo: 'Draw #1',
    },
    {
      title: 'Lottery Result 2',
      lotteryNumber: '54321',
      drawNo: 'Draw #2',
    },
    {
      title: 'Lottery Result 1',
      lotteryNumber: '12345',
      drawNo: 'Draw #1',
    },
    {
      title: 'Lottery Result 2',
      lotteryNumber: '54321',
      drawNo: 'Draw #2',
    },
    {
      title: 'Lottery Result 1',
      lotteryNumber: '12345',
      drawNo: 'Draw #1',
    },
    {
      title: 'Lottery Result 2',
      lotteryNumber: '54321',
      drawNo: 'Draw #2',
    },
    {
      title: 'Lottery Result 1',
      lotteryNumber: '12345',
      drawNo: 'Draw #1',
    },
    {
      title: 'Lottery Result 2',
      lotteryNumber: '54321',
      drawNo: 'Draw #2',
    },
    {
      title: 'Lottery Result 1',
      lotteryNumber: '12345',
      drawNo: 'Draw #1',
    },
    {
      title: 'Lottery Result 2',
      lotteryNumber: '54321',
      drawNo: 'Draw #2',
    },
    // Add more results as needed
  ];

  selectLottery(result: any) {
    // Implement your logic to handle the "Select Lottery" action here
    console.log('Selected lottery:', result);
  }
}