import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { LotteryService } from 'src/app/services/lottery.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {
   registrationForm: FormGroup;
  response: any;
  constructor(
    private data: LotteryService,
    private http: HttpClient,
    private fb: FormBuilder,
    ) {
      // กำหนดกฏการตรวจสอบข้อมูลใน FormGroup
    this.registrationForm = this.fb.group({
      prefix: ['นาย', Validators.required],
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      birthday: ['', Validators.required],
      phone: ['', Validators.required],
    });
  }
  performSearch() {
    // เรียกใช้เมธอด validateForm เพื่อตรวจสอบข้อมูลก่อนที่จะทำคำขอ API
    if (this.validateForm()) {
      // ทำคำขอ API เมื่อข้อมูลถูกต้อง
      const formData = this.registrationForm.value;
      this.apiService.add(
        formData.email,
        formData.password,
        formData.prefix,
        formData.firstName,
        formData.lastName,
        formData.birthday,
        formData.phone
      ).subscribe((data) => {
        // จัดการข้อมูลที่ได้รับจาก API ตรงนี้
        console.log(data);
      });
    }
  
   }
  
   validateForm() {
    // ตรวจสอบว่า FormGroup ถูกต้องหรือไม่
    if (this.registrationForm.valid) {
      return true;
    } else {
      // ถ้าไม่ถูกต้อง ให้ทำเครื่องหมายว่ามีข้อมูลไม่ถูกต้อง
      Object.keys(this.registrationForm.controls).forEach((field) => {
        const control = this.registrationForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
      return false;
    }
  
}
add(email: string, password: string, prefix: string, first_name: string, last_name: string, birthdate: string, phone_number: string) {
  console.log(email);
  console.log(password);
  console.log(prefix);
  console.log(first_name);
  console.log(last_name);
  console.log(birthdate);
  console.log(phone_number);

  let jsonObj = {
    email: email,
    password: password,
    prefix: prefix,
    first_name: first_name,
    last_name: last_name,
    birthdate: birthdate,
    phone_number: phone_number
  };

  // console.log(jsonObj);

  // Convert the JSON object to a JSON string
  let jsonString = JSON.stringify(jsonObj);
  
  // console.log(jsonString);
  
  // Send a POST request to the API endpoint
  this.http.post(this.data.apiEndpoint + "/users", jsonString, { observe: 'response' }).subscribe((response) => {
    console.log(response);
    console.log(JSON.stringify(response.status));
    console.log(JSON.stringify(response.body));
  
  });
}

}
