import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ChangeDetectorRef } from '@angular/core';
import { LotteryService } from '../../services/lottery.service';
import { MemberDataService } from 'src/app/services/member-data.service'; 
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent {
  constructor(
    private lotteryService: LotteryService,
    private http: HttpClient,
    private router: Router,
    private cdr: ChangeDetectorRef,
  ) {}

  login(email: string, password: string) {
    const data = {
      email: email,
      password: password,
    };

    let jsonString = JSON.stringify(data);

    this.http
      .post(this.lotteryService.apiEndpoint + "/login", jsonString)
      .subscribe(
        (response: any) => {
          // การตอบกลับเมื่อเข้าสู่ระบบสำเร็จ
          console.log('เข้าสู่ระบบสำเร็จ:', response);
          // ทำการนำผู้ใช้ไปยังหน้าหลักหรือทำตามที่คุณต้องการ
          this.lotteryService.isLoggedIn = true;

          // เรียกใช้งาน Service MemberDataService เพื่อเก็บชื่อสมาชิก
          this.lotteryService.setMemberName(response.name);

          this.router.navigate(['/member']);
          this.cdr.detectChanges();
        },
        (error) => {
          // การตอบกลับเมื่อเข้าสู่ระบบไม่สำเร็จ
          console.error('เข้าสู่ระบบไม่สำเร็จ:', error);
          // แสดงข้อความผิดพลาดถ้าต้องการ
        }
      );
  }
}
