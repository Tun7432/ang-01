// lottery-search.component.ts
import { Component } from '@angular/core';
import { Lottery, Convert as lotteryCvt } from 'src/app/model/Lottery.model';
import { LotteryService } from 'src/app/services/lottery.service';
import { HttpClient } from '@angular/common/http'; 
@Component({
  selector: 'app-lottery-search',
  templateUrl: './lottery-search.component.html',
  styleUrls: ['./lottery-search.component.css']
})
export class LotterySearchComponent {
  lotteryResults = Array<Lottery>();
  
  constructor(private lotteryService: LotteryService, private http: HttpClient) {
    // เรียก API และแปลงข้อมูลให้กับ lottery
    http.get(lotteryService.apiEndpoint+"/lottery").subscribe((data: any) => {
      this.lotteryResults = lotteryCvt.toLottery(JSON.stringify(data));
      console.log(data[0]);
      console.log(this.lotteryResults);
    });
  }
}


