import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

//โมดูลสำหรับส่วนของบุคคลทั่วไป (Public) ที่นำเข้า Component และกำหนดเส้นทางที่เฉพาะกับ Public

@NgModule({
  declarations: [],
  imports: [
    CommonModule
  ]
})
export class PublicModuleModule { }
