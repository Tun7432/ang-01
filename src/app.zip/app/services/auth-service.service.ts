import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthServiceService {

  constructor() { }
}
//ใช้สำหรับการจัดการการเข้าสู่ระบบและการตรวจสอบสิทธิ์การเข้าถึง