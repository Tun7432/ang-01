import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';


//โมดูลหลักของแอพพลิเคชันที่นำเข้า Component และกำหนดเส้นทางของแอพพลิเคชัน
@NgModule({
  declarations: [],
  imports: [
    CommonModule
  ]
})
export class AppModuleModule { }
